#print("hello,", end='')
#print(" world!")
print("hello,\tworld!")
print("hello,\nworld!")