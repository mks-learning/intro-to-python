# scope
# global / local

def getNumber():
   print(number)

number = 1
print(number)
getNumber()