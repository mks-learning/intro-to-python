class Sphere:
   def __init__(self, radius):
      self.radius = radius

sp = Sphere(4)