square = ((10,8), (10,23), (25,23), (25,8))
#for points in square:
#   print(points)
squareit = iter(square)
print(next(squareit))
print(next(squareit))
print(next(squareit))
print(next(squareit))