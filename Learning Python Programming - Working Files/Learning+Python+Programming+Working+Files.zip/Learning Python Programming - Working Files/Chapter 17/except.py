#print("Enter a numerator: ")
#numer = int(input())
#print("Enter a denominator: ")
#denom = int(input())
#quotient = numer / denom
#print(quotient)
file = open('blah.txt','r')