#for i in [1,2,3,4,5]:
#   print(i)
numbers = [1,2,3,4,5]
sum = 0
for x in numbers:
   sum = sum + x
print(sum)