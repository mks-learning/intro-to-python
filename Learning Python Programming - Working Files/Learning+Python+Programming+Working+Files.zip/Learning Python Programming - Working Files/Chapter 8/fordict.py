numbers = {'Cynthia':'2356', 'Raymond':'2345', 'David':'2373'}
#print(numbers.keys())
#print(numbers.values())
for key in numbers.keys():
   print(key + " extension is: " + numbers[key])