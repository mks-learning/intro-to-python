numbers = [1,2,3,4,5,6,7,8,9,10]
#for number in numbers:
#  print(number)
for i in range(0,len(numbers),3):
   print(numbers[i])